import { useLang } from '../hooks/useLang';

export default function Home({ onNav }) {
  const { t, cycleLang } = useLang();

  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '22px 22px 0' }}>
        {/* Topbar */}
        <div className="topbar" style={{ padding: '22px 0 0' }}>
          <div>
            <div className="serif" style={{ fontSize: 26, letterSpacing: -0.5 }}>
              Split<span style={{ color: 'var(--green-mid)' }}>ly</span>
            </div>
            <div className="kicker" style={{ marginTop: 2 }}>3 Tools. 1 App.</div>
          </div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <button className="pill pill-stone" onClick={cycleLang} style={{ border: 'none', cursor: 'pointer', fontFamily: 'var(--font-sans)' }}>
              {t.lang}
            </button>
            <button className="pill pill-ink" onClick={() => onNav('pro')} style={{ border: 'none', cursor: 'pointer', fontFamily: 'var(--font-sans)' }}>
              Pro ✦
            </button>
          </div>
        </div>

        <div style={{ height: 26 }} />

        {/* Hero */}
        <div className="kicker" style={{ marginBottom: 10 }}>{t.greeting}</div>
        <h1 className="serif" style={{ fontSize: 40, lineHeight: 1, letterSpacing: -1, marginBottom: 8 }}>
          {t.tagline}<br />
          <span className="serif-italic" style={{ color: 'var(--green-mid)' }}>{t.taglineItalic}</span>
        </h1>
        <p style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 1.65, marginBottom: 28, maxWidth: 280 }}>
          {t.subtitle}
        </p>

        {/* Feature tiles */}
        <div style={{ borderRadius: 'var(--rr)', padding: 22, background: 'var(--ink)', color: 'var(--bg)', cursor: 'pointer', marginBottom: 10, position: 'relative', overflow: 'hidden', transition: 'transform .16s' }}
          onClick={() => onNav('split')}
          onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-2px)'}
          onMouseLeave={e => e.currentTarget.style.transform = ''}
        >
          <div className="kicker" style={{ color: 'rgba(250,250,247,.4)', marginBottom: 10 }}>Gruppenentscheid</div>
          <div className="serif" style={{ fontSize: 24, marginBottom: 6 }}>{t.splithead}</div>
          <div style={{ fontSize: 12, opacity: .65, lineHeight: 1.5, maxWidth: 220 }}>{t.splitDesc}</div>
          <div style={{ display: 'inline-block', fontSize: 9, fontWeight: 600, letterSpacing: 1, textTransform: 'uppercase', padding: '3px 8px', borderRadius: 20, background: 'rgba(255,255,255,.12)', marginTop: 12 }}>{t.splitFree}</div>
          <div style={{ position: 'absolute', right: 20, bottom: 20, fontSize: 20, opacity: .35 }}>→</div>
        </div>

        <div style={{ borderRadius: 'var(--rr)', padding: 22, background: 'var(--green-mid)', color: '#fff', cursor: 'pointer', marginBottom: 18, position: 'relative', overflow: 'hidden', transition: 'transform .16s' }}
          onClick={() => onNav('bill')}
          onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-2px)'}
          onMouseLeave={e => e.currentTarget.style.transform = ''}
        >
          <div className="kicker" style={{ color: 'rgba(255,255,255,.45)', marginBottom: 10 }}>Rechnungsteiler</div>
          <div className="serif" style={{ fontSize: 24, marginBottom: 6 }}>{t.billsplit}</div>
          <div style={{ fontSize: 12, opacity: .65, lineHeight: 1.5, maxWidth: 220 }}>{t.billDesc}</div>
          <div style={{ display: 'inline-block', fontSize: 9, fontWeight: 600, letterSpacing: 1, textTransform: 'uppercase', padding: '3px 8px', borderRadius: 20, background: 'rgba(255,255,255,.15)', marginTop: 12 }}>{t.billFree}</div>
          <div style={{ position: 'absolute', right: 20, bottom: 20, fontSize: 20, opacity: .35 }}>→</div>
        </div>

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 8, marginBottom: 22 }}>
          {[
            { n: '2.4M', l: t.decisions },
            { n: '840k', l: t.bills },
            { n: '140+', l: t.countries },
          ].map(s => (
            <div key={s.l} className="card" style={{ textAlign: 'center', padding: 12 }}>
              <div className="serif" style={{ fontSize: 22, marginBottom: 2 }}>{s.n}</div>
              <div className="kicker">{s.l}</div>
            </div>
          ))}
        </div>

        {/* Recent */}
        <div className="kicker" style={{ marginBottom: 10 }}>{t.recent}</div>
        {[
          { icon: '🍕', bg: 'var(--stone)', title: 'Wo essen wir?', meta: '2 Std. · 3 Personen', badge: 'Fertig', badgeBg: 'var(--stone)', badgeColor: 'var(--ink)' },
          { icon: '🧾', bg: 'var(--green-light)', title: 'Abendessen — 4 Personen', meta: 'CHF 23.50 pro Person', badge: 'Bezahlt', badgeBg: 'var(--green-light)', badgeColor: 'var(--green)' },
        ].map((item, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 0', borderBottom: i === 0 ? '1px solid var(--border)' : 'none' }}>
            <div style={{ width: 38, height: 38, borderRadius: 11, background: item.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0 }}>{item.icon}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 500 }}>{item.title}</div>
              <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 1 }}>{item.meta}</div>
            </div>
            <div style={{ fontSize: 10, fontWeight: 600, padding: '3px 9px', borderRadius: 20, background: item.badgeBg, color: item.badgeColor, whiteSpace: 'nowrap' }}>{item.badge}</div>
          </div>
        ))}
        <div style={{ height: 20 }} />
      </div>
    </div>
  );
}
