import { useState } from 'react';
import { useLang } from '../hooks/useLang';

const MEMBERS = [
  { init: 'JO', name: 'Josua', bg: '#FEE', color: 'var(--red)' },
  { init: 'LA', name: 'Laura', bg: 'var(--green-light)', color: 'var(--green)' },
  { init: 'MI', name: 'Mike', bg: 'var(--amber-light)', color: 'var(--amber)' },
];

const VOTE_DATA = [
  { e: '🍕', t: 'Pizza bei Napoli', p: 67, v: 2 },
  { e: '🍜', t: 'Ramen House', p: 33, v: 1 },
  { e: '🥗', t: 'Vegis Corner', p: 0, v: 0 },
];

export default function Splithead({ onNav }) {
  const { t } = useLang();
  const [step, setStep] = useState(1);
  const [question, setQuestion] = useState('Wo essen wir heute Abend?');
  const [options, setOptions] = useState(['🍕 Pizza bei Napoli', '🍜 Ramen House', '🥗 Vegis Corner']);
  const [voted, setVoted] = useState(false);
  const [chosenIdx, setChosenIdx] = useState(null);
  const used = 8;

  function addOption() {
    setOptions(o => [...o, '']);
  }

  function castVote(idx) {
    if (voted) return;
    setVoted(true);
    setChosenIdx(idx);
    setTimeout(() => setStep(3), 400);
  }

  function reset() {
    setStep(1); setVoted(false); setChosenIdx(null);
  }

  return (
    <div style={{ flex: 1, overflowY: 'auto', padding: 22 }}>
      <div className="topbar" style={{ padding: '0 0 20px' }}>
        <button className="btn btn-outline btn-sm" onClick={() => onNav('home')} style={{ width: 'auto' }}>← {t.back}</button>
        <div className="serif" style={{ fontSize: 19 }}>{t.splithead}</div>
        <div style={{ fontSize: 11, fontWeight: 500, color: 'var(--muted)' }}>10/{t.decisions}</div>
      </div>

      {/* STEP 1 */}
      {step === 1 && (
        <div className="fade-up">
          {/* Limit bar */}
          <div style={{ background: 'var(--stone)', border: '1px solid var(--border)', borderRadius: 'var(--r)', padding: '10px 14px', fontSize: 12, color: 'var(--muted)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}>
            <span>{used} {t.limitNote}</span>
            <span style={{ fontWeight: 600, color: 'var(--ink)', cursor: 'pointer' }} onClick={() => onNav('pro')}>{t.limitUpgrade}</span>
          </div>

          <div className="kicker" style={{ color: 'var(--green-mid)', marginBottom: 5 }}>{t.newDecision}</div>
          <h2 className="serif" style={{ fontSize: 26, marginBottom: 6 }}>{t.question}</h2>
          <p style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 1.6, marginBottom: 18 }}>
            Stelle eine Frage, füge Optionen hinzu, lade deine Gruppe ein — fertig.
          </p>

          <input className="inp" value={question} onChange={e => setQuestion(e.target.value)} placeholder={t.questionPlaceholder} />

          <div className="field-lbl">{t.options}</div>
          {options.map((o, i) => (
            <input key={i} className="inp" value={o} onChange={e => { const n = [...options]; n[i] = e.target.value; setOptions(n); }} placeholder={`Option ${i + 1}`} />
          ))}
          <button className="btn btn-outline btn-sm" onClick={addOption} style={{ marginBottom: 16 }}>{t.addOption}</button>

          <div className="field-lbl">{t.invite}</div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 18 }}>
            {MEMBERS.map(m => (
              <div key={m.init} className="mem-chip">
                <div className="mem-av" style={{ background: m.bg, color: m.color }}>{m.init}</div>
                {m.name}
              </div>
            ))}
            <div className="mem-chip" style={{ cursor: 'pointer', borderStyle: 'dashed', color: 'var(--muted)' }}
              onClick={() => alert(t.copied)}>+ {t.invite}</div>
          </div>

          <button className="btn btn-ink" onClick={() => setStep(2)}>{t.startVote}</button>
        </div>
      )}

      {/* STEP 2 */}
      {step === 2 && (
        <div className="fade-up">
          <div className="kicker" style={{ color: 'var(--green-mid)', marginBottom: 5 }}>Schritt 2</div>
          <h2 className="serif" style={{ fontSize: 26, marginBottom: 6 }}>{question}</h2>
          <p style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 1.6, marginBottom: 18 }}>{t.voteDesc}</p>

          {options.filter(o => o).map((o, i) => (
            <div key={i}
              onClick={() => castVote(i)}
              style={{
                background: chosenIdx === i ? 'var(--stone)' : 'var(--white)',
                border: `1.5px solid ${chosenIdx === i ? 'var(--ink)' : 'var(--border)'}`,
                borderRadius: 'var(--r)', padding: '14px 16px', marginBottom: 8,
                display: 'flex', alignItems: 'center', gap: 12,
                cursor: voted ? 'default' : 'pointer', transition: 'all .16s',
              }}
            >
              <span style={{ fontSize: 20, width: 28, textAlign: 'center' }}>{o.split(' ')[0]}</span>
              <span style={{ fontSize: 13, fontWeight: 500 }}>{o}</span>
            </div>
          ))}

          <div style={{ textAlign: 'center', marginTop: 12, fontSize: 11, color: 'var(--muted)' }}>
            3 {t.of} 3 {t.voted}
          </div>
        </div>
      )}

      {/* STEP 3 */}
      {step === 3 && (
        <div className="fade-up">
          {/* Verdict */}
          <div style={{ background: 'var(--ink)', borderRadius: 'var(--rr)', padding: 22, textAlign: 'center', marginBottom: 14, color: 'var(--bg)' }}>
            <div className="kicker" style={{ color: 'rgba(250,250,247,.4)', marginBottom: 8 }}>{t.groupDecided}</div>
            <div className="serif" style={{ fontSize: 30, marginBottom: 6 }}>{options[0]}</div>
            <div style={{ fontSize: 12, opacity: .6, lineHeight: 1.5 }}>
              2 {t.of} 3 {t.votes}. {t.noMoreDiscussion}
            </div>
          </div>

          {VOTE_DATA.map((r, i) => (
            <div key={i} style={{
              background: i === 0 ? 'var(--ink)' : 'var(--white)',
              color: i === 0 ? 'var(--bg)' : 'var(--ink)',
              border: `1.5px solid ${i === 0 ? 'var(--ink)' : 'var(--border)'}`,
              borderRadius: 'var(--r)', padding: '14px 16px', marginBottom: 7,
              display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <span style={{ fontSize: 20, width: 28, textAlign: 'center' }}>{r.e}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{r.t}</div>
                <div style={{ height: 2, background: i === 0 ? 'rgba(255,255,255,.2)' : 'var(--border)', borderRadius: 1, marginTop: 5 }}>
                  <div style={{ height: 2, width: `${r.p}%`, background: i === 0 ? 'rgba(255,255,255,.6)' : 'var(--ink)', borderRadius: 1, transition: 'width .5s' }} />
                </div>
                <div style={{ fontSize: 10, color: i === 0 ? 'rgba(250,250,247,.55)' : 'var(--muted)', marginTop: 2 }}>
                  {r.v} {r.v === 1 ? t.vote1 : t.votes} · {r.p}%
                </div>
              </div>
            </div>
          ))}

          <div style={{ height: 10 }} />
          <button className="btn btn-ink" onClick={reset}>{t.newDecisionBtn}</button>
          <div style={{ height: 8 }} />
          <button className="btn btn-outline" onClick={() => onNav('home')}>{t.backOverview}</button>
        </div>
      )}
    </div>
  );
}
