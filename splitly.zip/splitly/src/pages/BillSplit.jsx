import { useState } from 'react';
import { useLang } from '../hooks/useLang';

const PEOPLE = [
  { init: 'JO', name: 'Josua', bg: '#FEE', color: 'var(--red)', items: ['🍕 Pizza Margherita', '🍺 Bier'], amount: 28.50 },
  { init: 'LA', name: 'Laura', bg: 'var(--green-light)', color: 'var(--green)', items: ['🥗 Caesar Salad', '💧 Wasser'], amount: 18.00 },
  { init: 'MI', name: 'Mike', bg: 'var(--amber-light)', color: 'var(--amber)', items: ['🍝 Pasta', '🍷 Wein'], amount: 26.50 },
  { init: 'SO', name: 'Sophie', bg: 'var(--blue-light)', color: 'var(--blue)', items: ['🍔 Burger', '🍹 Cocktail'], amount: 21.00 },
];

const ITEMS = [
  { e: '🍕', name: 'Pizza Margherita', who: 'Josua', price: 18.00 },
  { e: '🍺', name: 'Bier', who: 'Josua', price: 10.50 },
  { e: '🥗', name: 'Caesar Salad', who: 'Laura', price: 16.00 },
  { e: '💧', name: 'Wasser', who: 'Laura', price: 2.00 },
  { e: '🍝', name: 'Pasta Carbonara', who: 'Mike', price: 19.00 },
  { e: '🍷', name: 'Wein', who: 'Mike', price: 7.50 },
  { e: '🍔', name: 'Cheeseburger', who: 'Sophie', price: 21.00 },
];

export default function BillSplit({ onNav }) {
  const { t } = useLang();
  const [step, setStep] = useState(1);
  const [method, setMethod] = useState('equal');
  const [total, setTotal] = useState('94.00');

  const totalNum = parseFloat(total) || 0;
  const perPerson = (totalNum / PEOPLE.length).toFixed(2);

  const METHODS = [
    { id: 'equal', icon: '÷', label: t.equalSplit },
    { id: 'each', icon: '🧾', label: t.eachOwn },
    { id: 'manual', icon: '✏️', label: t.manual },
  ];

  return (
    <div style={{ flex: 1, overflowY: 'auto', padding: 22 }}>
      <div className="topbar" style={{ padding: '0 0 20px' }}>
        <button className="btn btn-outline btn-sm" onClick={() => step === 1 ? onNav('home') : setStep(1)} style={{ width: 'auto' }}>← {t.back}</button>
        <div className="serif" style={{ fontSize: 19 }}>{t.billsplit}</div>
        <div style={{ width: 60 }} />
      </div>

      {/* STEP 1 */}
      {step === 1 && (
        <div className="fade-up">
          <div className="kicker" style={{ color: 'var(--green-mid)', marginBottom: 5 }}>{t.newBill}</div>
          <h2 className="serif" style={{ fontSize: 26, marginBottom: 6 }}>{t.howSplit}</h2>
          <p style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 1.6, marginBottom: 18 }}>{t.howSplitDesc}</p>

          {/* Method selector */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 7, marginBottom: 18 }}>
            {METHODS.map(m => (
              <div key={m.id}
                onClick={() => setMethod(m.id)}
                style={{
                  padding: '12px 8px', borderRadius: 'var(--r)',
                  border: `1.5px solid ${method === m.id ? 'var(--ink)' : 'var(--border)'}`,
                  background: method === m.id ? 'var(--stone)' : 'var(--white)',
                  cursor: 'pointer', textAlign: 'center', transition: 'all .15s',
                }}>
                <div style={{ fontSize: 20, marginBottom: 4 }}>{m.icon}</div>
                <div style={{ fontSize: 10, fontWeight: 500, color: method === m.id ? 'var(--ink)' : 'var(--muted)', lineHeight: 1.3 }}>{m.label}</div>
              </div>
            ))}
          </div>

          <div className="field-lbl">{t.total}</div>
          <div style={{ position: 'relative', marginBottom: 8 }}>
            <span style={{ position: 'absolute', left: 15, top: '50%', transform: 'translateY(-50%)', fontFamily: 'var(--font-serif)', fontSize: 18, color: 'var(--muted)' }}>CHF</span>
            <input
              className="inp"
              type="number"
              value={total}
              onChange={e => setTotal(e.target.value)}
              style={{ paddingLeft: 56, fontFamily: 'var(--font-serif)', fontSize: 28, fontWeight: 600, marginBottom: 0 }}
            />
          </div>

          <div className="field-lbl">{t.persons}</div>
          {PEOPLE.map((p, i) => (
            <div key={i} style={{ background: 'var(--white)', border: '1px solid var(--border)', borderRadius: 'var(--r)', padding: '12px 14px', marginBottom: 7, display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ width: 36, height: 36, borderRadius: '50%', background: p.bg, color: p.color, fontSize: 12, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{p.init}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{p.name}</div>
                <div style={{ fontSize: 10, color: 'var(--muted)', marginTop: 1 }}>{p.items.join(' · ')}</div>
              </div>
              <div className="serif" style={{ fontSize: 18, fontWeight: 600 }}>
                CHF {method === 'equal' ? perPerson : p.amount.toFixed(2)}
              </div>
            </div>
          ))}

          <div style={{ height: 14 }} />
          <button className="btn btn-green" onClick={() => setStep(2)}>{t.showResult}</button>
        </div>
      )}

      {/* STEP 2 — Result */}
      {step === 2 && (
        <div className="fade-up">
          {/* Result card */}
          <div style={{ background: 'var(--green-mid)', borderRadius: 'var(--rr)', padding: 22, marginBottom: 14, color: '#fff' }}>
            <div className="kicker" style={{ color: 'rgba(255,255,255,.55)', marginBottom: 7 }}>
              {t.splitBy} {PEOPLE.length}
            </div>
            <div className="serif" style={{ fontSize: 22, marginBottom: 14 }}>
              CHF {totalNum.toFixed(2)} total
            </div>
            {PEOPLE.map((p, i) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: i < PEOPLE.length - 1 ? '1px solid rgba(255,255,255,.15)' : 'none', fontSize: 13 }}>
                <div>
                  <div>{p.name}</div>
                  <div style={{ fontSize: 10, opacity: .55, marginTop: 1 }}>{p.items.join(' · ')}</div>
                </div>
                <div className="serif" style={{ fontSize: 17, fontWeight: 600 }}>
                  CHF {method === 'equal' ? perPerson : p.amount.toFixed(2)}
                </div>
              </div>
            ))}
          </div>

          <div className="kicker" style={{ marginBottom: 10 }}>{t.items}</div>
          {ITEMS.map((item, i) => (
            <div key={i} style={{ background: 'var(--white)', border: '1px solid var(--border)', borderRadius: 'var(--r)', padding: '11px 14px', marginBottom: 6, display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontSize: 18, width: 24, textAlign: 'center', flexShrink: 0 }}>{item.e}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{item.name}</div>
                <div style={{ fontSize: 10, color: 'var(--muted)', marginTop: 1 }}>{item.who}</div>
              </div>
              <div style={{ fontSize: 13, fontWeight: 600 }}>CHF {item.price.toFixed(2)}</div>
            </div>
          ))}

          <div style={{ height: 14 }} />
          <button className="btn btn-green" onClick={() => alert('Link teilen — alle sehen was sie schulden')}>{t.shareResult}</button>
          <div style={{ height: 8 }} />
          <button className="btn btn-outline" onClick={() => setStep(1)}>{t.back}</button>
          <div style={{ height: 20 }} />
        </div>
      )}
    </div>
  );
}
