import { useState } from 'react';
import { useLang } from '../hooks/useLang';

const FEATURES_KEY = [
  'unlimited', 'unlimitedBills', 'groups50',
  'shareLink', 'saveGroups', 'stats', 'adFree',
];

export default function Pro({ onNav }) {
  const { t } = useLang();
  const [plan, setPlan] = useState('yearly');

  const price = plan === 'monthly' ? 'CHF 3.99' : 'CHF 29.99';
  const period = plan === 'monthly' ? t.perMonth : t.perYear;

  return (
    <div style={{ flex: 1, overflowY: 'auto', padding: 22 }}>
      <div className="topbar" style={{ padding: '0 0 20px' }}>
        <button className="btn btn-outline btn-sm" onClick={() => onNav('home')} style={{ width: 'auto' }}>← {t.back}</button>
        <div className="serif" style={{ fontSize: 19 }}>Splitly Pro</div>
        <div style={{ width: 60 }} />
      </div>

      {/* Hero */}
      <div style={{ background: 'var(--ink)', borderRadius: 'var(--rr)', padding: '26px 22px', marginBottom: 18, color: 'var(--bg)' }}>
        <div className="kicker" style={{ opacity: .35, marginBottom: 8 }}>{t.upgrade}</div>
        <div className="serif" style={{ fontSize: 36, lineHeight: 1, marginBottom: 4 }}>
          Splitly<br />
          <span className="serif-italic" style={{ color: '#6EE7A0' }}>Pro.</span>
        </div>
        <div style={{ fontSize: 13, opacity: .5, marginBottom: 20 }}>{t.proDesc}</div>

        <hr style={{ border: 'none', borderTop: '1px solid rgba(255,255,255,.08)', margin: '0 0 16px' }} />

        {FEATURES_KEY.map(key => (
          <div key={key} style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 13, opacity: .8, padding: '6px 0', borderBottom: '1px solid rgba(255,255,255,.06)' }}>
            <div style={{ width: 18, height: 18, borderRadius: '50%', background: '#6EE7A0', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, color: 'var(--ink)', fontWeight: 700, flexShrink: 0 }}>✓</div>
            {t[key]}
          </div>
        ))}
      </div>

      {/* Plan selector */}
      <div className="kicker" style={{ marginBottom: 10 }}>Plan wählen</div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 16 }}>
        {[
          { id: 'monthly', label: t.monthly, price: 'CHF 3.99', note: t.perMonth, save: null },
          { id: 'yearly', label: t.yearly, price: 'CHF 29.99', note: t.perYear, save: t.twoFree },
        ].map(p => (
          <div key={p.id}
            onClick={() => setPlan(p.id)}
            style={{
              background: 'var(--white)',
              border: `1.5px solid ${plan === p.id ? 'var(--ink)' : 'var(--border)'}`,
              borderRadius: 'var(--rr)', padding: 16,
              textAlign: 'center', cursor: 'pointer',
              background: plan === p.id ? 'var(--stone)' : 'var(--white)',
              transition: 'all .15s',
            }}>
            <div className="kicker" style={{ marginBottom: 6 }}>{p.label}</div>
            <div className="serif" style={{ fontSize: 28, fontWeight: 700, marginBottom: 2 }}>{p.price}</div>
            <div style={{ fontSize: 10, color: 'var(--muted)' }}>{p.note}</div>
            {p.save && <div style={{ fontSize: 10, fontWeight: 600, color: 'var(--green-mid)', marginTop: 3 }}>{p.save}</div>}
          </div>
        ))}
      </div>

      <button className="btn btn-ink" onClick={() => alert('Stripe Checkout: ' + price)}>
        {t.upgradeNow} — {price}
      </button>
      <div style={{ textAlign: 'center', marginTop: 10, fontSize: 11, color: 'var(--muted)' }}>{t.cancelAnytime}</div>

      <div style={{ height: 24 }} />
    </div>
  );
}
