import { createContext, useContext, useState } from 'react';
import { translations, langOrder } from '../i18n/translations';

const LangContext = createContext(null);

export function LangProvider({ children }) {
  const [langIdx, setLangIdx] = useState(0);
  const lang = langOrder[langIdx];
  const t = translations[lang];
  const cycleLang = () => setLangIdx(i => (i + 1) % langOrder.length);
  return (
    <LangContext.Provider value={{ t, lang, cycleLang }}>
      {children}
    </LangContext.Provider>
  );
}

export function useLang() {
  return useContext(LangContext);
}
