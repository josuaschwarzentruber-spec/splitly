import { useLang } from '../hooks/useLang';

const TABS = [
  { id: 'home', icon: '⌂', key: 'home' },
  { id: 'split', icon: '🤝', key: 'splithead' },
  { id: 'bill', icon: '🧾', key: 'billsplit' },
  { id: 'pro', icon: '✦', key: 'pro' },
];

export default function BottomNav({ active, onNav }) {
  const { t } = useLang();
  return (
    <nav className="bnav">
      {TABS.map(tab => (
        <div
          key={tab.id}
          className={`bni ${active === tab.id ? 'active' : ''}`}
          onClick={() => onNav(tab.id)}
        >
          <span className="bni-ic">{tab.icon}</span>
          <span className="bni-lb">{t[tab.key]}</span>
          <div className="bni-dot" />
        </div>
      ))}
    </nav>
  );
}
